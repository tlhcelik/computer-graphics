#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    img = new graphic(this);
    img->setGeometry(120,10,300,300);
    img->setFrameShape(QFrame::Box);
    img->show();


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
   radius = ui->lineEdit->text().toInt();
   while(radius >= 0){
    img->bresenham_with_draw_circle(radius);
    radius -=1;
   }

}

void MainWindow::on_pushButton_2_clicked()
{
    img->draw_polygon();
}
