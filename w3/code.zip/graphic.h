#ifndef GRAPHIC_H
#define GRAPHIC_H

#include <QWidget>
#include <QLabel>
#include <QImage>
#include<QMouseEvent>

// for polygon
#include <QList>
#include <QPoint>

class graphic : public QLabel
{
public:
    graphic(QWidget *parent);

    QPoint point;
    QList<QPoint> points;

    QPoint ilkNokta;
    QImage res;
    void mousePressEvent(QMouseEvent*);

    //algorithms
    void bresenham_with_draw_circle(int radius);

    void draw_polygon();
    void cidDDA(QPoint first, QPoint last);
};

#endif // GRAPHIC_H
