#include "graphic.h"
#include <math.h>
#include <qmath.h>
#include<QApplication>

graphic::graphic(QWidget *parent) : QLabel(parent)
{
    QImage ortam(300,300,QImage::Format_RGB32);
    setPixmap(QPixmap::fromImage(ortam));
    res = ortam;
}

void graphic::mousePressEvent(QMouseEvent *e)
{
    //points is a QList
    points.push_back(e->pos());
    ilkNokta=e->pos();
}


void graphic::bresenham_with_draw_circle(int radius)
{

        int X, Y, XC, YC, RADIUS_ERROR;
        X = radius;
        Y = 0;
        XC = 1 - (2*radius); // x degisim
        YC = 1; // y degisim

        RADIUS_ERROR = 0;

        while (X >= Y) {

            res.setPixel(ilkNokta.x() + X, ilkNokta.y() + Y ,qRgb(255,0,0));
            res.setPixel(ilkNokta.x() - X, ilkNokta.y() + Y ,qRgb(255,0,0));

            res.setPixel(ilkNokta.x() - X ,ilkNokta.y() - Y ,qRgb(255,0,0));
            res.setPixel(ilkNokta.x() + X, ilkNokta.y() - Y ,qRgb(255,0,0));

            res.setPixel(ilkNokta.x() + Y, ilkNokta.y() + X ,qRgb(255,0,0));
            res.setPixel(ilkNokta.x() - Y, ilkNokta.y() + X ,qRgb(255,0,0));

            res.setPixel(ilkNokta.x() - Y, ilkNokta.y() - X ,qRgb(255,0,0));
            res.setPixel(ilkNokta.x() + Y, ilkNokta.y() - X ,qRgb(255,0,0));

            setPixmap(QPixmap::fromImage(res));
            QApplication::processEvents();

            Y += 1;
            RADIUS_ERROR += YC;
            YC += 2;

            if ( (2 * RADIUS_ERROR) + XC > 0) {
                X -= 1;
                RADIUS_ERROR += XC;
                XC += 2;
            }
        }
}

void graphic::draw_polygon()
{
    points.push_back(points[0]); // poligonun kapanmasi icin ilk elemani en sona ekledik
    for(int i = 0; i < points.size() -1; i++){
        cidDDA(points[i], points[i+1]);
    }
    points.clear();
}

void graphic::cidDDA(QPoint first, QPoint last)
{
    double dx = last.x() - first.x();
    double dy = last.y() - first.y();
    double x_artim, y_artim;
    double adim; // dongu sayisi, formuldeki toplam Pixel sayisi anlamina geliyor
    double x, y;

    if (fabs(dx) > fabs(dy)) {
        adim = fabs(dx);
    } else {
        adim = fabs(dy);
    }

    x_artim = dx / adim;
    y_artim = dy / adim;

    x = first.x();
    y = first.y();

    for (int i = 0; i < adim; ++i) {
        x += x_artim; //Xn+1 = Xn + Xfark;
        y += y_artim;

        res.setPixel(round(x),round(y),qRgb(255,0,0));
        setPixmap(QPixmap::fromImage(res));
        QApplication::processEvents();

    }
}



